const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const KEY='study-os-v1';
const initial=()=>({quests:[
{id:1,title:'Aakash Class 12 JEE',desc:"Primary priority · today's focused chapter work",xp:50,type:'Aakash · Class 12',done:false},
{id:2,title:'Active recall + PYQs',desc:'Solve independently; review mistakes',xp:50,type:'Aakash · Class 12',done:false},
{id:3,title:'Vedantu Eklavya Class 11',desc:'Secondary priority · lecture or scheduled backlog',xp:35,type:'Vedantu · Class 11',done:false},
{id:4,title:'Revision + error log',desc:'Recall formulas and revisit mistakes',xp:25,type:'Revision / Test',done:false}],
routine:[
{time:'8:00 AM – 2:00 PM',name:'School',desc:'Classes + school worksheets'},
{time:'3:00 – 4:00 PM',name:'Aakash / doubt class',desc:'Primary JEE Class 12 work'},
{time:'4:00 – 6:00 PM',name:'Focused self-study',desc:'Aakash questions and weak topics'},
{time:'6:00 – 6:30 PM',name:'Eklavya backlog',desc:'Class 11 lecture or scheduled prep'},
{time:'7:00 – 8:30 PM',name:'Gym / recovery',desc:'Training and travel as applicable'},
{time:'Later evening',name:'Revision + plan tomorrow',desc:'Flexible slot; protect sleep'}],
focusSeconds:0,streak:0,nextId:5,nextRoutineId:7});
let data;
try{data=JSON.parse(localStorage.getItem(KEY))||initial()}catch{data=initial()}
let seconds=1800,mode='focus',running=false,interval=null,audioCtx=null,osc=null,gain=null;
function save(){try{localStorage.setItem(KEY,JSON.stringify(data))}catch{}}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
const totalXP=()=>data.quests.filter(q=>q.done).reduce((n,q)=>n+q.xp,0);
const doneCount=()=>data.quests.filter(q=>q.done).length;
const level=()=>Math.floor(totalXP()/200)+1;
function say(t){$('#message').textContent=t}
function questHTML(q){return `<div class="quest ${q.done?'done':''}"><input type="checkbox" data-q="${q.id}" aria-label="Complete ${esc(q.title)}" ${q.done?'checked':''}><div class="quest-copy"><div class="quest-title">${esc(q.title)}</div><div class="quest-desc">${esc(q.desc)}</div><div class="small">${esc(q.type)}</div></div><div class="quest-xp">+${q.xp} XP</div></div>`}
function render(){
 const xp=totalXP(),done=doneCount(),n=data.quests.length,pct=n?Math.round(done/n*100):0;
 $('#xp').textContent=xp;$('#streak').textContent=data.streak+' days';$('#quest-count').textContent=`${done}/${n}`;
 $('#quest-percent').textContent=pct+'% cleared';$('#quest-progress').style.width=pct+'%';
 $('#home-quests').innerHTML=data.quests.slice(0,3).map(questHTML).join('');
 $('#all-quests').innerHTML=data.quests.map(questHTML).join('');
 $('#level').textContent=`LV. ${level()} · ${level()===1?'NOVICE':'RISING'}`;
 $('#stat-xp').textContent=xp;$('#stat-done').textContent=done;$('#stat-minutes').textContent=Math.floor(data.focusSeconds/60);$('#stat-level').textContent=level();
 $('#level-label').textContent=`${xp%200} / 200 XP`;$('#level-progress').style.width=(xp%200)/2+'%';
 renderRoutine();
}
function renderRoutine(){$('#routine').innerHTML=data.routine.map(x=>`<div class="quest"><div class="quest-copy"><div class="quest-title">${esc(x.time)} · ${esc(x.name)}</div><div class="quest-desc">${esc(x.desc)}</div></div><button class="secondary" data-rdel="${x.id}" aria-label="Remove ${esc(x.name)}">×</button></div>`).join('')}
function timerRender(){$('#timer').textContent=`${String(Math.floor(seconds/60)).padStart(2,'0')}:${String(seconds%60).padStart(2,'0')}`;$('#timer-label').textContent=mode==='focus'?'FOCUS SESSION':'REFRESH BREAK';$('#timer-toggle').textContent=running?'Ⅱ Pause':'▶ Start';$('#timer-progress').style.width=((mode==='focus'?1800:420)-seconds)/(mode==='focus'?1800:420)*100+'%'}
function setMode(m){mode=m;seconds=m==='focus'?1800:420;running=false;clearInterval(interval);interval=null;timerRender()}
function finish(){running=false;clearInterval(interval);interval=null;if(mode==='focus'){data.focusSeconds+=1800;save();setMode('break');say('🌸 Focus cycle complete — take a 7-minute break.')}else{setMode('focus');say('⚔ Break complete — ready for another focus cycle?')}render();timerRender()}
$$('.tab').forEach(b=>b.addEventListener('click',()=>openView(b.dataset.view)));
$$('[data-open]').forEach(b=>b.addEventListener('click',()=>openView(b.dataset.open)));
function openView(v){$$('.tab').forEach(b=>b.classList.toggle('active',b.dataset.view===v));$$('.view').forEach(s=>s.classList.toggle('active',s.id===v));window.scrollTo({top:0,behavior:'smooth'})}
document.addEventListener('change',e=>{if(e.target.matches('[data-q]')){const q=data.quests.find(x=>x.id===Number(e.target.dataset.q));if(q){q.done=e.target.checked;save();render();say(q.done?`✨ Quest cleared! +${q.xp} XP`:'Quest reopened. Keep building momentum.')}}});
$('#quest-form').addEventListener('submit',e=>{e.preventDefault();const title=$('#new-title').value.trim();if(!title)return;data.quests.push({id:data.nextId++,title,desc:'Custom quest · show up and make progress',xp:25,type:$('#new-type').value,done:false});save();render();e.target.reset();say('New quest added! +25 XP awaits.')});
$('#routine-form').addEventListener('submit',e=>{e.preventDefault();const name=$('#routine-title').value.trim(),time=$('#routine-time').value.trim();if(!name||!time)return;data.routine.push({id:data.nextRoutineId++,name,time,desc:'Custom schedule item'});save();renderRoutine();e.target.reset();say('Schedule updated and saved on this device.')});
document.addEventListener('click',e=>{const b=e.target.closest('[data-rdel]');if(b){data.routine=data.routine.filter(x=>x.id!==Number(b.dataset.rdel));save();renderRoutine();say('Schedule item removed.')}});
$('#timer-toggle').addEventListener('click',()=>{if(running){running=false;clearInterval(interval);interval=null;timerRender();say('Timer paused. Resume whenever ready.');return}running=true;timerRender();interval=setInterval(()=>{seconds--;if(mode==='focus')data.focusSeconds++;timerRender();if(seconds<=0)finish();if(seconds%15===0){save();$('#stat-minutes').textContent=Math.floor(data.focusSeconds/60)}},1000);say('Focus timer running. One step at a time.')});
$('#timer-skip').addEventListener('click',()=>{setMode(mode==='focus'?'break':'focus');say('Timer phase changed manually.')});
$('#timer-reset').addEventListener('click',()=>{setMode('focus');say('Timer reset to 30 minutes.')});
$('#ambient-toggle').addEventListener('click',async()=>{try{if(osc){osc.stop();osc=null;$('#ambient-toggle').textContent='♫ Play ambient tone';$('#audio-status').textContent='Sound is off.';return}audioCtx=audioCtx||new(window.AudioContext||window.webkitAudioContext)();await audioCtx.resume();osc=audioCtx.createOscillator();gain=audioCtx.createGain();osc.type='sine';osc.frequency.value=220;gain.gain.value=.018;osc.connect(gain);gain.connect(audioCtx.destination);osc.start();$('#ambient-toggle').textContent='Ⅱ Stop ambient tone';$('#audio-status').textContent='Soft generated ambient tone playing — not a lofi song.'}catch{$('#audio-status').textContent='Audio unavailable in this browser. Use the external lofi link.'}});
$('#export').addEventListener('click',()=>{const text=['STUDY_OS SESSION SUMMARY',`XP: ${totalXP()}`,`Level: ${level()}`,`Quests: ${doneCount()}/${data.quests.length}`,`Focus minutes: ${Math.floor(data.focusSeconds/60)}`,'','QUESTS',...data.quests.map(q=>`${q.done?'[x]':'[ ]'} ${q.title} — ${q.xp} XP`)].join('\n');const url=URL.createObjectURL(new Blob([text],{type:'text/plain'}));const a=document.createElement('a');a.href=url;a.download='study-os-summary.txt';a.click();URL.revokeObjectURL(url);say('Session summary exported.')});
$('#reset-data').addEventListener('click',()=>{if(!confirm('Reset all quests, schedule edits and saved progress?'))return;data=initial();save();render();say('Progress reset. Fresh chapter, fresh start.')});
if('serviceWorker'in navigator&&location.protocol.startsWith('http'))navigator.serviceWorker.register('./sw.js').catch(()=>{});
render();timerRender();
